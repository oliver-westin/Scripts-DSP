//////////////////////////////////////////////////////////////////////
//PLL da fase A
void Calculo_Pa(void)
{
    Pota[i]=(Valfa*Senoa)+(Vbeta*Cossenoa);
    ErroPIa[1]=Pota[i];
}
void GeraSenoa(void)
{
    if (i==1){
        Tetaa[i]=(IntegradorNum*Wa[i])+(IntegradorNum*Wa[0])-(IntegradorDen*Tetaa[0]);
        if (Tetaa[i]>=6.28318){
            Tetaa[i]=0;
        }
            if(Tetaa[i]<6.28318){
                EndSenoa=Tetaa[i]*95.49304651;
                EndCossenoa=EndSenoa+150;
                if(EndCossenoa>599){
                    EndCossenoa=EndCossenoa-600;
                }
                Senoa=Tab_Seno[EndSenoa];
                Cossenoa=Tab_Seno[EndCossenoa];
            }
        Wa[0]=Wa[i];
        Tetaa[0]=Tetaa[i];
        Cossenoa=-Cossenoa;
        Calculo_Pa();
    }else{
        Tetaa[i]=(IntegradorNum*Wa[i]);
        Senoa=0;
        Cossenoa=-1;
        Tetaa[0]=Tetaa[i];
        Calculo_Pa();
    }
}
void PI_PLLa(void)
{
    Wa[i]=377;
    if (i==1){
        //Wa[i]=(PI_NumPLL0*ErroPIa[i])+(PI_NumPLL1*ErroPIa[0])-(PI_DenPLL1*Wa[0]);
        ErroPIa[0]=ErroPIa[i];

    }else{
        //Wa[i]=(PI_NumPLL0*ErroPIa[i]);
    }
}

void PLLa(void)
{
    PI_PLLa();
    GeraSenoa();
}
//////////////////////////////////////////////////////////////////////
