void PLL(void)
{
    //Altera��o PLL com filtro adaptativo


        if (w1<100){ //Condi��o Necess�ria para inicializa��o (N�o pode dividir por zero)
            w1=100;
        }
        //y2 = y*w1;
        y2 = y*0.00555555555555555555555555555556;
        Pot = (Seno*y2) - (Cosseno*Seno);
        e = (Valfa*180)-y;

        uw1 = e*Cosseno*ganhoFA; //360 -> 2*u*60e3    u=0.003
        w1 = (IntegradorNum*uw1)+(IntegradorNum*uw1_0)+(w1_0);
        uw1_0 = uw1;
        w1_0 = w1;

        uw2 = e*Seno*360;  //360 -> 2*u*(1/60e3)    u=0.003
        w2 = (IntegradorNum*uw2)+(IntegradorNum*uw2_0)+(w2_0);
        uw2_0 = uw2;
        w2_0 = w2;

        y = (Cosseno*w1) + (Seno*w2);
       //Vpico=sqrt(w1*w1+w2*w2);
       Vpico = 180; // modo ilhado, comentar linha de cima e descomentar essa
    ErroPI_PLL=-Pot;

    W=((PI_NumPLL0*ErroPI_PLL+PI_NumPLL1*ErroPI_PLL_0)+W_0);
            ErroPI_PLL_0=ErroPI_PLL;
            W_0=W;

    //W=W+Wff;
    W = Wff; // modo ilhado, comentar linha de cima e descomentar essa
    Teta=(IntegradorNum*W)+(IntegradorNum*Wi_0)+(Teta_0);
        Teta_0=Teta;
        Wi_0=W;


        if (Teta>6.283){
        Teta=0;

        }
        if (Teta<-6.283){
        Teta=0;

        }

                EndSenoa=Teta*95.49304651;  //95.49 -> 600/(2*pi)
                EndCossenoa=EndSenoa+150;

                if(EndCossenoa>599)
                {
                    EndCossenoa=EndCossenoa-600;
                }
                Seno=Tab_Seno[EndSenoa];
                Cosseno=Tab_Seno[EndCossenoa];

            Teta_0=Teta;
}




/*//////////////////////////////////////////////////////////////////////
//PLL da fase A
void Calculo_Pa(void)
{
    Pota[i]=(Valfa*Senoa)+(Vbeta*Cossenoa);
    ErroPIa[1]=Pota[i];
}
void GeraSenoa(void)
{
    if (i==1){
        Tetaa[i]=(IntegradorNum*Wa[i])+(IntegradorNum*Wa[0])-(IntegradorDen*Tetaa[0]);
        if (Tetaa[i]>=6.28318){
            Tetaa[i]=0;
            Tetaa[0]=0;
        }
            if(Tetaa[i]<6.28318){
                EndSenoa=Tetaa[i]*95.49304651;
                EndCossenoa=EndSenoa+150;
                if(EndCossenoa>599){
                    EndCossenoa=EndCossenoa-599;
                }
                Senoa=Tab_Seno[EndSenoa];
                Cossenoa=Tab_Seno[EndCossenoa];
            }
        Wa[0]=Wa[i];

        //Senoa=sin(Tetaa[i]);
        // Cossenoa=cos(Tetaa[i]);

        Tetaa[0]=Tetaa[i];
        Cossenoa=-Cossenoa;
        Calculo_Pa();
    }else{
        Tetaa[i]=(IntegradorNum*Wa[i]);


        //Senoa=sin(Tetaa[i]);
        //Cossenoa=cos(Tetaa[i]);
        Senoa=0;
        Cossenoa=-1;
        Tetaa[0]=Tetaa[i];

        Cossenoa=-Cossenoa;
        Calculo_Pa();
    }
}
void PI_PLLa(void)
{
    if (i==1){
        Wa[i]=(PI_NumPLL0*ErroPIa[i])+(PI_NumPLL1*ErroPIa[0])-(PI_DenPLL1*Wa[0]);
        ErroPIa[0]=ErroPIa[i];
    }else{
        Wa[i]=(PI_NumPLL0*ErroPIa[i]);
    }
}

void PLLa(void)
{
    PI_PLLa();
    GeraSenoa();
}
//////////////////////////////////////////////////////////////////////
*/
