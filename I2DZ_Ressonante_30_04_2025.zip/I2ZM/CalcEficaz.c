/*
 * CalcEficaz.c
 *
 *  Created on: 20 de jan de 2022
 *      Author: Anderson Dionizio
 */

void Eficaz(void)
{
    Iinef_calc += Iin*Iin;
    Ioef_calc += Iout*Iout;
    Ilmef_calc += Ilm_fil*Ilm_fil;

    //Vinef_calc += Vin*Vin;
    Voef_calc += Vout*Vout;
    Vcaef_calc += Vca*Vca;
    //Vdc2ef_calc += Vdc2*Vdc2;

    if (contaEficaz==5000)
        {

            //calculo das correntes eficazes
            Iinef=sqrt(Iinef_calc*0.0002);
            Ioef=sqrt(Ioef_calc*0.0002);
            Ilmef=sqrt(Ilmef_calc*0.0002);

           // Vinef=sqrt(Vinef_calc*0.0002);
            Voef=sqrt(Voef_calc*0.0002);
            Vcaef=sqrt(Vcaef_calc*0.0002);
            //Vdc2ef=sqrt(Vdc2ef_calc*0.0002);


            Iinef_calc=0;
            Ioef_calc=0;
            Ilmef_calc=0;
            //Vinef_calc=0;
            Voef_calc=0;
            Vcaef_calc=0;
          //  Vdc2ef_calc=0;


            contaEficaz=1;
        }
        else
            contaEficaz++;
}


