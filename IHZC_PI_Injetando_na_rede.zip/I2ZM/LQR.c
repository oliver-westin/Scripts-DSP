/*
 * LQR.c
 *
 *  Created on: 11 de fevereiro de 2025
 *      Author: Oliver Westin
 */

    void LQR(void){

        //C�lculo dos m�dulos das leituras, independente do ganho dos sensores

        if(Ilm_fil<0)
            Ilm_mod=-Ilm_fil;
        else
            Ilm_mod=Ilm_fil;
        if(Iout_fil<0)
            Iout_mod=-Iout_fil;
        else
            Iout_mod=Iout_fil;
        if(Vca<0)
            Vca_mod=-Vca;
        else
            Vca_mod=Vca;
        if(Vout<0)
            Vout_mod=-Vout;
        else
            Vout_mod=Vout;



        // Ganhos Ks do LQR em AConstantes
        erroIout_ant = erroIout;
        erroK5 = erroIout_ant*K5 + erroK5_ant;
        erroK5_ant = erroK5;

        AcCtrl = -(Ilm_mod*K1 + Iout_mod*K2 + Vca_mod*K3 + Vout_mod*K4 + erroK5)*inv_Wctrl;
       // AcCtrl = -(erroIout*K5*inv_Wctrl);

        //Prote��o para satura��o

        if(AcCtrl>0.88*Wctrl)
            AcCtrl = 0.88*Wctrl;

        if(AcCtrl<0)
            AcCtrl = 0;

    }

