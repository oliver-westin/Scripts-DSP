void PO(void){
	

	pot=Vin*Iin;
	//%%%%%%%%%%%%%%%%%%%% Calculo da Pot�ncia M�dia %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
		
	p_soma=p_soma+pot;
	I_soma=I_soma+Iin;
	V_soma=V_soma+Vin;

	cont_p_soma=cont_p_soma+1;
//50000
	if (cont_p_soma>=50000){
		pot_med=p_soma*0.00002;
		I_med=I_soma*0.00002;
		V_med=V_soma*0.00002;
		cont_p_soma=0;
		p_soma=0;
		I_soma=0;
		V_soma=0;


		pot=pot_med;
		//Ipv=I_med;
		//Vpv=V_med;


		//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	
		Vpvref=Vpvref_ant;
	
		pot_ant=Vpv_ant*Ipv_ant;

		dV=V_med-Vpv_ant;

		dP=pot-pot_ant;

		if(dP<0){
	
			if(dV>0){	
				Vpvref=Vpvref-inc;   //%% dP<0 e dI<0   Somar Iref
			}	
			if(dV<0){
				Vpvref=Vpvref+inc;  //%% dP<0 e dI>0   Subtrair Iref
			}
		
		}
		if(dP>0){
			if(dV<0){
				Vpvref=Vpvref-inc;  //%% dP>0 e dI>0   Somar Iref
			}
			if(dV>0){
				Vpvref=Vpvref+inc;  //%% dP>0 e dI<0   Subtrair Iref
			}
		}

		if(Vpvref>Vmax){
			Vpvref=Vmax;
		}
		if(Vpvref<Vmin){
			Vpvref=Vmin;
		}

		Vpvref_ant=Vpvref;
		Vpv_ant=V_med;
		Ipv_ant=I_med;
		pot_ant=pot;
	}

}
