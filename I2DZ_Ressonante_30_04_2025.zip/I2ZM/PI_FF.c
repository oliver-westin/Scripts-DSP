/*
 * PI_FF.c
 *
 *  Created on: 23 de fev de 2022
 *      Author: Anderson Dionizio
 */

void PI_FF(void)
{
    // Multi- malhas

// === Equacao a diferen�a do controlador PI Discretizado atrav�s do M�todo de Tustin ===

    outPI = (PI_numz_Vref1*erroVref) + (PI_numz_Vref2*erroVref_ant) + outPI_ant;
    erroVref_ant = erroVref;  // Salva erro anterior
    outFF = Vin*Iin*2/180;



    if (outPI>6) outPI=6;
    if (outPI<-6) outPI=-6;

    IoutRef = outPI+outFF;

    if (IoutRef>6) IoutRef=6;
    if (IoutRef<0) IoutRef=0;

    IoutRef_ant = IoutRef;        // Salva a��o de controle anterior
    outPI_ant = outPI;
}


