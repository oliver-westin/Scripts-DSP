//###########################################################################
//
// FILE:    A_ProgramaBase.c
//
// TITLE:   Inversor H�brido Zeta Cuk
//
// DATA DE ATUALIZA��O: 22/11/2024
//
//
//  Taxa de amostragem padr�o = 60 kHz.
//  Frequ�ncia de clock = 150 MHz.
//  O Programa inclui fun��es externas que executam um algoritmo p-PLL ("APLL.c"),
//  um filtro passa baixa FPB ("AFiltro.c").
//  Constantes globais s�o definidas por meio de outra fun��o externa ("AConstantes.c").
//
////###########################################################################

// Inclus�o de Bibliotecas
#include "DSP28x_Project.h"
#include "math.h"

float32 dmax=0;

//vari�veis comunicacao
int habEnvio=0;
Uint16 varS,ReceivedChar;
int16 var;
int contaEnvio=0;
int sec=1;
float32 tabEnvio[5];
char buffer[12];
//int conta1=0,conta2=0;conta3=0;
int habPosto=0;
Uint16 contaseg=0,contamili=0,seg=0;
float32 valor;

float32 kdes=0.05;
int partrampa=0,desliga=0,ilhado=0,ligaMPPT=0;


//Ressonante de corrente
float32 acd_h1=0, acd_h1_sat=0, acd_h1_ant=0, acd_h1_ant_2=0, erroIout_ant_2=0, erroIout_sat_ant=0, erroIout_sat_ant_2=0;
float32 acd_h3=0, acd_h3_ant=0, acd_h3_ant_2=0;
float32 acd_h5=0, acd_h5_ant=0, acd_h5_ant_2=0;
float32 acd_h7=0, acd_h7_ant=0, acd_h7_ant_2=0;
float32 acd_h9=0, acd_h9_ant=0, acd_h9_ant_2=0;
float32 acd_h11=0, acd_h11_ant=0, acd_h11_ant_2=0;

//Ressonante de tens�o
float32 acdV_h1=0, acdV_h1_sat=0, acdV_h1_ant=0, acdV_h1_ant_2=0;
float32 acdV_h3=0, acdV_h3_ant=0, acdV_h3_ant_2=0;
float32 acdV_h5=0, acdV_h5_ant=0, acdV_h5_ant_2=0;
float32 acdV_h7=0, acdV_h7_ant=0, acdV_h7_ant_2=0;
float32 acdV_h9=0, acdV_h9_ant=0, acdV_h9_ant_2=0;
float32 acdV_h11=0, acdV_h11_ant=0, acdV_h11_ant_2=0;
float32 acdV_h13=0, acdV_h13_ant=0, acdV_h13_ant_2=0;
float32 acdV_h15=0, acdV_h15_ant=0, acdV_h15_ant_2=0;

float32 habR=0.0, habPI=0.2;

float32 Iref=0,Irefamp=0.6,saida=0,Hist=0.05,erro=0,IrefMax=4.5;
float32 meio1=0,meio2=0;
//void calcEficaz(void);

//Controle com a rede
Uint16 ligarede=0;
//PI de corrente de sa�da
float32 compErro=0,aciIout=0,aciIout_ant=0;
float32 aciIoutPI=0,aciIoutPI_ant=0;
float32 aciIoutR=0,aciIoutR_ant=0;
float32 erroIout=0,erroIout_ant=0;
float32 KpI=0.05;
Uint16 rampaneg=0;


//PI de tens�o de sa�da
float32 IoutRef=0,IoutRef_ant=0,acd_Iout=0,acd_Iout_ant=0,aciVout=0,aciVout_ant=0,outPI=0,outPI_ant=0,outFF=0;
float32 erroVout=0,erroVout_ant=0, erroVout_ant_2=0, erroVout_ant3=0, aciPI =0;
float32 erroVout2=0,erroVout2_ant=0;
float32 Vref=0, Vrefamp=50;


int alto1=0,alto2=0,liga=0,histerese=0,malhafechada=0,malhaaberta=0,FF=0;
//vari�veis dos sensores
int16 Current0,Current1,Current2,Voltage1,Voltage2,Voltage3;
float32 Voltage0[250];
float32 Iin=0, Iout=0, Ilm=0;

float32 Vin=0, Vca=0, Vdc1=0,Vdc2=0,Vout=0;

float32 Iinef=0,Iinef_calc=0,contaEficaz=0;
float32 Ioef=0,Ioef_calc=0;
float32 Vinef=0,Vinef_calc=0;
float32 Vdc2ef=0,Vdc2ef_calc=0;
float32 Voef=0,Voef_calc=0;

float32 escala1=0.016,escala2=0.016,escala3=1,escala4=1,escala5=1;

//Vari�veis do PLL
float32 Tetaa[2], Pota[2], Wa[2], ErroPIa[2];
float32 Senoa, Cossenoa;
//Uint16 EndSenoa, EndCossenoa;

float32 Valfa, Vbeta;

float32 Tab_Seno[600]={0,0.010471775,0.020942402,0.031410731,0.041875616,0.052335909,0.062790463,0.073238131,0.083677768,0.094108228,0.104528369,0.114937047,0.12533312,0.13571545,0.146082897,0.156434324,0.166768597,0.177084581,0.187381146,0.197657163,0.207911505,0.218143046,0.228350666,0.238533245,0.248689666,0.258818815,0.268919582,0.278990859,0.289031542,0.299040529,0.309016723,0.31895903,0.328866359,0.338737625,0.348571744,0.358367639,0.368124234,0.377840461,0.387515253,0.39714755,0.406736295,0.416280438,0.42577893,0.435230731,0.444634804,0.453990118,0.463295647,0.472550371,0.481753274,0.490903348,0.499999588,0.509040998,0.518026586,0.526955367,0.535826361,0.544638596,0.553391106,0.562082929,0.570713115,0.579280715,0.587784791,0.596224409,0.604598645,0.61290658,0.621147303,0.629319911,0.637423506,0.645457201,0.653420114,0.661311373,0.669130112,0.676875473,0.684546607,0.692142673,0.699662838,0.707106277,0.714472174,0.721759721,0.72896812,0.736096578,0.743144316,0.75011056,0.756994546,0.763795519,0.770512733,0.777145453,0.783692949,0.790154505,0.796529412,0.80281697,0.809016491,0.815127294,0.82114871,0.827080077,0.832920746,0.838670076,0.844327436,0.849892207,0.855363777,0.860741548,0.866024928,0.87121334,0.876306213,0.881302989,0.886203121,0.891006071,0.895711312,0.900318328,0.904826615,0.909235677,0.913545032,0.917754206,0.921862739,0.925870179,0.929776087,0.933580034,0.937281605,0.940880392,0.944376001,0.947768049,0.951056164,0.954239984,0.957319162,0.960293359,0.96316225,0.965925519,0.968582863,0.971133992,0.973578625,0.975916494,0.978147344,0.980270928,0.982287015,0.984195384,0.985995825,0.98768814,0.989272144,0.990747664,0.992114537,0.993372614,0.994521756,0.995561838,0.996492746,0.997314378,0.998026642,0.998629463,0.999122772,0.999506516,0.999780654,0.999945155,1,0.999945184,0.999780714,0.999506606,0.999122891,0.998629612,0.998026822,0.997314587,0.996492985,0.995562107,0.994522054,0.993372942,0.992114894,0.990748051,0.989272561,0.987688586,0.9859963,0.984195889,0.98228755,0.980271492,0.978147937,0.975917117,0.973579276,0.971134672,0.968583573,0.965926257,0.963163017,0.960294155,0.957319987,0.954240838,0.951057045,0.947768959,0.94437694,0.940881359,0.9372826,0.933581057,0.929777137,0.925871257,0.921863845,0.91775534,0.913546193,0.909236865,0.90482783,0.90031957,0.895712581,0.891007366,0.886204443,0.881304338,0.876307587,0.87121474,0.866026355,0.860743,0.855365256,0.84989371,0.844328965,0.83867163,0.832922325,0.827081681,0.821150338,0.815128947,0.809018168,0.802818672,0.796531137,0.790156254,0.783694722,0.777147248,0.770514552,0.763797361,0.756996411,0.750112447,0.743146226,0.73609851,0.728970073,0.721761696,0.71447417,0.707108295,0.699664876,0.692144732,0.684548687,0.676877573,0.669132232,0.661313514,0.653422275,0.645459381,0.637425705,0.629322128,0.62114954,0.612908835,0.604600918,0.5962267,0.587787099,0.579283041,0.570715458,0.56208529,0.553393482,0.544640989,0.535828771,0.526957792,0.518029027,0.509043454,0.500002059,0.490905834,0.481755775,0.472552886,0.463298176,0.453992661,0.44463736,0.4352333,0.425781512,0.416283032,0.406738902,0.397150169,0.387517884,0.377843103,0.368126888,0.358370303,0.348574419,0.33874031,0.328869054,0.318961734,0.309019437,0.299043252,0.289034274,0.2789936,0.268922331,0.258821572,0.24869243,0.238536016,0.228353445,0.218145831,0.207914296,0.197659961,0.187383949,0.17708739,0.16677141,0.156437143,0.14608572,0.135718277,0.125335951,0.114939881,0.104531207,0.094111069,0.083680611,0.073240977,0.062793311,0.052338758,0.041878467,0.031413583,0.020945254,0.010474628,0,-0.010468921,-0.020939548,-0.031407878,-0.041872765,-0.052333059,-0.062787615,-0.073235285,-0.083674924,-0.094105387,-0.104525531,-0.114934212,-0.125330289,-0.135712623,-0.146080074,-0.156431506,-0.166765783,-0.177081773,-0.187378343,-0.197654366,-0.207908714,-0.218140262,-0.228347888,-0.238530474,-0.248686902,-0.258816059,-0.268916834,-0.278988119,-0.28902881,-0.299037806,-0.309014009,-0.318956325,-0.328863664,-0.33873494,-0.34856907,-0.358364975,-0.368121581,-0.377837819,-0.387512623,-0.397144931,-0.406733689,-0.416277843,-0.425776348,-0.435228162,-0.444632248,-0.453987576,-0.463293118,-0.472547856,-0.481750773,-0.490900861,-0.499997117,-0.509038542,-0.518024145,-0.526952942,-0.535823952,-0.544636203,-0.553388729,-0.562080569,-0.570710771,-0.579278389,-0.587782482,-0.596222118,-0.604596372,-0.612904325,-0.621145067,-0.629317693,-0.637421307,-0.645455021,-0.653417954,-0.661309232,-0.669127991,-0.676873372,-0.684544527,-0.692140613,-0.699660799,-0.707104259,-0.714470177,-0.721757746,-0.728966166,-0.736094647,-0.743142407,-0.750108673,-0.756992681,-0.763793677,-0.770510915,-0.777143657,-0.783691177,-0.790152756,-0.796527687,-0.802815269,-0.809014814,-0.815125641,-0.821147081,-0.827078473,-0.832919167,-0.838668522,-0.844325907,-0.849890703,-0.855362299,-0.860740095,-0.866023501,-0.871211939,-0.876304838,-0.881301641,-0.886201799,-0.891004775,-0.895710043,-0.900317086,-0.9048254,-0.90923449,-0.913543871,-0.917753073,-0.921861633,-0.9258691,-0.929775036,-0.933579012,-0.93728061,-0.940879425,-0.944375063,-0.947767139,-0.951055282,-0.954239131,-0.957318337,-0.960292563,-0.963161482,-0.96592478,-0.968582153,-0.971133311,-0.973577973,-0.975915872,-0.97814675,-0.980270364,-0.982286481,-0.984194879,-0.985995349,-0.987687693,-0.989271727,-0.990747276,-0.992114179,-0.993372286,-0.994521458,-0.99556157,-0.996492507,-0.997314169,-0.998026463,-0.998629313,-0.999122652,-0.999506427,-0.999780594,-0.999945125,-1,-0.999945214,-0.999780774,-0.999506696,-0.999123011,-0.998629761,-0.998027001,-0.997314796,-0.996493224,-0.995562375,-0.994522353,-0.99337327,-0.992115252,-0.990748438,-0.989272978,-0.987689033,-0.985996776,-0.984196395,-0.982288085,-0.980272056,-0.97814853,-0.975917739,-0.973579928,-0.971135353,-0.968584282,-0.965926996,-0.963163784,-0.960294952,-0.957320812,-0.954241691,-0.951057927,-0.947769869,-0.944377878,-0.940882325,-0.937283594,-0.93358208,-0.929778188,-0.925872335,-0.92186495,-0.917756473,-0.913547353,-0.909238053,-0.904829045,-0.900320812,-0.89571385,-0.891008662,-0.886205765,-0.881305686,-0.876308962,-0.871216141,-0.866027782,-0.860744453,-0.855366734,-0.849895214,-0.844330494,-0.838673184,-0.832923904,-0.827083285,-0.821151967,-0.8151306,-0.809019846,-0.802820373,-0.796532862,-0.790158003,-0.783696494,-0.777149044,-0.770516371,-0.763799203,-0.756998275,-0.750114334,-0.743148135,-0.736100442,-0.728972026,-0.721763671,-0.714476167,-0.707110312,-0.699666915,-0.692146792,-0.684550767,-0.676879674,-0.669134353,-0.661315654,-0.653424435,-0.64546156,-0.637427903,-0.629324346,-0.621151776,-0.61291109,-0.604603191,-0.596228991,-0.587789408,-0.579285367,-0.570717801,-0.56208765,-0.553395859,-0.544643383,-0.53583118,-0.526960218,-0.518031468,-0.509045911,-0.500004531,-0.49090832,-0.481758275,-0.472555401,-0.463300705,-0.453995203,-0.444639916,-0.435235869,-0.425784094,-0.416285627,-0.406741509,-0.397152788,-0.387520514,-0.377845745,-0.368129541,-0.358372967,-0.348577093,-0.338742995,-0.328871749,-0.318964439,-0.309022151,-0.299045975,-0.289037006,-0.27899634,-0.268925079,-0.258824328,-0.248695194,-0.238538788,-0.228356223,-0.218148616,-0.207917087,-0.197662758,-0.187386752,-0.177090198,-0.166774224,-0.156439961,-0.146088543,-0.135721104,-0.125338782,-0.114942716,-0.104534045,-0.09411391,-0.083683455,-0.073243823,-0.062796158,-0.052341608,-0.041881318,-0.031416435,-0.020948107,-0.010477481};



float32 Vpico=0;
float32 W=0;
float32 W_0=0;
float32 ErroPI_PLL=0;
float32 ErroPI_PLL_0=0;
float32 Teta=0;
float32 Teta_0=0;
float32 Seno=0;
float32 Cosseno=0;
float32 Pot=0;
float32 Wi_0=0;
float32 d=0;
float32 y=0, y2=0;
float32 w1=0;
float32 w2=0;
float32 e=0;
float32 uw1 = 0;
float32 uw1_0 = 0;
float32 w1_0 = 0;
float32 uw2 = 0;
float32 uw2_0 = 0;
float32 w2_0 = 0;
int16 EndSenoa=0;
int16 EndCossenoa=0;
int16 EndSenob=0;
int16 EndCossenob=0;
float32 Senob=0;
float32 Cossenob=0;
int16 EndSenoc=0;
int16 EndCossenoc=0;
float32 Senoc=0;
float32 Cossenoc=0;


//


//vari�veis controle Zeta
float32 D=0.15,Dl=0.7,histU=0,Dctr=0;



// Variaveis globais usadas nesse projeto:
Uint16 LoopCount;
Uint16 ConversionCount;
Uint16 ConversionCount0;
Uint16 FlagDeConversao;
Uint16 q, i;
//float32 png1[400], png2[400];
float32 TempA, TempB, Wctrl=4999;//2999 Wctrl




float32 Vdc, Vdcfil;






    //Vari�veis globais do PLL
//float32 Teta[2], Pot[2], W[2], ErroPI[2];
//float32 Seno, Cosseno;


//%%%%%%%%%%%%%%%%%%%%% DECLARA��O DAS VARIAVEIS PO %%%%%%%%%%%%%%%%%%%%%%%%%%%%
float32 Vpv_ant=150, Ipv_ant, Vpvref_ant=150, dP, dV, pot, pot_ant, Vpvref=150,erroVref=0,erroVref_ant=0;
float32 I_soma, V_soma, I_med, V_med, cont_p_soma=0, p_soma=0, pot_med=0,usata_PI_ant=0;
float32 Vmax=180,Vmin=100,inc=0.5;

// Vari�veis globais do Filtro
float32 fpbinVdc[2]; 
float32 fpboutVdc[2];

float32 fpbinVdc1=0,fpbinVdc1_ant=0;
float32 fpboutVdc1=0,fpboutVdc1_ant=0;
float32 fpbinVdc2=0,fpbinVdc2_ant=0;
float32 fpboutVdc2=0,fpboutVdc2_ant=0;
float32 Vdc1fil=0, Vdc2fil=0;
float32 desb1=0;


// Fun��es utilizadas nesse arquivo e escritas ap�s a fun��o main
interrupt void adc_isr(void);
interrupt void epwm1_isr(void);
void ConfigEPwm(void);
void Gpio_select(void);
//Configura��o e Interrup��es da comunica��o Serial
void SCIA_init(void);



void armazena(void);

// Inclus�o das fun��es que n�o est�o escritas nesse arquivo mas pertencem ao projeto
#include "AConstantes.c"
#include "AFiltro.c"
//#include "APLL_old.c"
//#include "APLL.c"
//#include "PLL2.c"
#include "PI_Iout.c"
//#include "PI_Balance.c"
//#include "PI_Vo.c"
#include "PI_Vo_Ilhado.c"
#include "CalcEficaz.c"
//#include "aPO.c"
//#include "PI_Vin.c"
//#include "PI_FF.c"
#include "ressonante.c"
#include "Vout_Ressonante.c"

void main(void)


{

// Defini��o do HSPCLK ("DSP2833x_SysCtrl.c") .
   EALLOW;
   #if (CPU_FRQ_150MHZ)     // Default - 150 MHz SYSCLKOUT
    #define ADC_MODCLK 0x3  // HSPCLK = SYSCLKOUT/2*ADC_MODCLK2 = 150/(2*3)   = 25.0 MHz
   #endif
   #if (CPU_FRQ_100MHZ)
     #define ADC_MODCLK 0x2 // HSPCLK = SYSCLKOUT/2*ADC_MODCLK2 = 100/(2*2)   = 25.0 MHz
   #endif
   EDIS;
   
// Inicializa��es:

   Gpio_select();// Seleciona o pino GPIO60 como sa�da
   
   InitSysCtrl();// Inicializa controles do sistema e desabilita watchdog 

// Essas fun��es se encontram dentro do arquivo DSP2833x_EPwm.c file
   InitEPwm1Gpio();// Inicializa pinos do GPIO para o ePWM1
   InitEPwm2Gpio();// Inicializa pinos do GPIO para o ePWM2
   InitEPwm3Gpio();// Inicializa pinos do GPIO para o ePWM3


   
   DINT;// Desabilita todas as interrup��es

// Essa fun��o se encontra dentro do arquivo DSP2833x_PieCtrl.c file.
   InitPieCtrl();// Inicializa registratores de controle do PIE para o estado default
   
// Limpa todos os flags e enable de interrup��o
   IER = 0x0000;
   IFR = 0x0000;

// Initialize the PIE vector table with pointers to the shell Interrupt 
// Service Routines (ISR).  
// This will populate the entire table, even if the interrupt
// is not used in this example.  This is useful for debug purposes.
// The shell ISR routines are found in DSP2833x_DefaultIsr.c.
// This function is found in DSP2833x_PieVect.c.
   InitPieVectTable();

// Interrupts that are used in this example are re-mapped to
// ISR functions found within this file.  
   EALLOW;  // This is needed to write to EALLOW protected registers
   PieVectTable.EPWM1_INT = &epwm1_isr;
   PieVectTable.ADCINT = &adc_isr;


   EDIS;    // This is needed to disable write to EALLOW protected registers

   SCIA_init();  // Initalize SCI

// This function is found in DSP2833x_InitPeripherals.c
   InitAdc();  // Inicializa o ADC

 
   PieCtrlRegs.PIEIER1.bit.INTx6 = 1;// Enable ADCINT in PIE
   IER |= M_INT1; // Enable CPU Interrupt 1

// Configura��o do ADC

   AdcRegs.ADCTRL1.bit.ACQ_PS = 4;          // Acquisition window size
   AdcRegs.ADCTRL1.bit.CPS = 1;             // Core clock pre-scaler
   AdcRegs.ADCTRL1.bit.CONT_RUN = 0;        // 0:Start-Stop or continuous sequencer mode
   AdcRegs.ADCTRL3.bit.ADCCLKPS = 3;        // Core clock divider
   AdcRegs.ADCTRL3.bit.ADCBGRFDN = 0x3;     // Bandgap and reference powered up
   AdcRegs.ADCTRL3.bit.SMODE_SEL = 0;     // 1:Simultaneous, 0:Sequential sampling
   AdcRegs.ADCREFSEL.bit.REF_SEL = 0 ;      // Set Refernce Voltage
   AdcRegs.ADCOFFTRIM.bit.OFFSET_TRIM = 0;  // Set Offset Error Correctino Value
   AdcRegs.ADCTRL1.bit.SEQ_CASC = 1;

   AdcRegs.ADCMAXCONV.all = 3;              // Setup 1 conv's on SEQ1

   AdcRegs.ADCCHSELSEQ1.bit.CONV00 = 0xA;   // Setup ADCINA0 e A0

   AdcRegs.ADCCHSELSEQ1.bit.CONV01 = 0x9;
   AdcRegs.ADCCHSELSEQ1.bit.CONV02 = 0x2;   // Setup ADCINA2 e B0
   AdcRegs.ADCCHSELSEQ1.bit.CONV03 = 0x0;

   /*


   AdcRegs.ADCCHSELSEQ1.bit.CONV04 = 0xA;   // Setup ADCINB2 as 1st SEQ1 conv.


   AdcRegs.ADCCHSELSEQ2.bit.CONV05 = 0xB;   // Setup ADCINB3 as 1st SEQ1 conv.
   AdcRegs.ADCCHSELSEQ2.bit.CONV06 = 0xC;   // Setup ADCINB4 as 1st SEQ1 conv.
   AdcRegs.ADCCHSELSEQ2.bit.CONV07 = 0xD;   // Setup ADCINB5 as 1st SEQ1 conv.
   */
   //Modo de aquisi��o e interrup��o
   AdcRegs.ADCTRL2.bit.EPWM_SOCA_SEQ1 = 1;  // Enable SOCA from ePWM to start SEQ1
   AdcRegs.ADCTRL2.bit.INT_ENA_SEQ1 = 1;    // Enable SEQ1 interrupt (every EOS)

// Assumes ePWM1 clock is already enabled in InitSysCtrl();
   EPwm6Regs.ETSEL.bit.SOCAEN = 1;        // Enable SOC on A group
   EPwm6Regs.ETSEL.bit.SOCASEL = 2;       // Select SOC from PRD
   EPwm6Regs.ETPS.bit.SOCAPRD = 1;        // Generate pulse on 1st event
   EPwm6Regs.TBPRD = 1250;//60ks          // Set period for ePWM1 TBPRD = (FCLK/2*TAXA AMOSTRAGEM)-1
   EPwm6Regs.TBCTL.bit.CTRMODE = 0;       // count up and start
   
   EALLOW;
   SysCtrlRegs.PCLKCR0.bit.TBCLKSYNC = 0;
   EDIS;

   ConfigEPwm();// Configura ePWM
   
        // Inicializa os comparadores de modo as sa�das dos ePWM sejam baixas (0)
        EPwm1Regs.CMPA.half.CMPA = Wctrl;
        EPwm1Regs.CMPB = 0;

        EPwm2Regs.CMPA.half.CMPA = 0;
        EPwm2Regs.CMPB = 0;

        EPwm3Regs.CMPA.half.CMPA = Wctrl;
        EPwm3Regs.CMPB= 0;

   
   EALLOW;
   SysCtrlRegs.PCLKCR0.bit.TBCLKSYNC = 1;// Habilita sincronismo dos ePWM
   EDIS;

   IER |= M_INT3;// Enable CPU INT3 which is connected to EPWM1-3 INT:
   PieCtrlRegs.PIEIER3.bit.INTx1 = 1;// Enable EPWM INTn in the PIE: Group 3 interrupt 1-3

   EINT;   // Enable Global interrupt INTM
   ERTM;   // Enable Global realtime interrupt DBGM

// Inicializa as vari�veis no passo 0
ConversionCount = 0;
ConversionCount0 = 0;
q=0; i=0; TempA=0; TempB=0;
//Pot[0]=0;Seno=0;
//Pota[0]=0;ErroPIa[0]=0;Cossenoa=0;Senoa=0;
GpioDataRegs.GPBCLEAR.bit.GPIO58=1;
contamili=0;
    while(1){
        if (FlagDeConversao==1){//inicio

        GpioDataRegs.GPBSET.bit.GPIO60=1;


/*            Iout=(float)(Current0);//Corrente de sa�da
            Iin =(float)(Current1);//Corrente de entrada



            //Vout = (float)(Voltage0[ConversionCount2]);//tens�o de sa�da
            Vout = (float)(Voltage0);//tens�o de sa�da
            Vin = (float)(Voltage1);//tens�o de entrada soma dos dois capacitores
            //Vdc2 = (float)(Voltage2);//tens�o de entrada barramento CC1

            Iin = -(Iin-2281)*(0.012195);
            Iout = (Iout-2274)*(0.01234568);



            Vout = (Vout-2451)*(-0.333333333);
            Vin = (Vin-2446)*(-0.320855615);
            //Vdc2 = (Vdc2-2433)*(-0.33577777778);
            //Vdc1 = Vin - Vdc2;*/

        Ilm = (float)(Current0);//Corrente no indutor Lm
        Iin = (float)(Current1);//Corrente de entrada
        Iout =(float)(Current2);//Corrente de sa�da

        Vout = (float)(Voltage0[ConversionCount0]);    //Tens�o de sa�da
        Vdc2 = (float)(Voltage1);       //Tens�o no split-capacitor
        Vin = (float)(Voltage2);        //Tens�o de entrada soma dos dois capacitores
        Vca = (float)(Voltage3);        //Tens�o no capacitor de acoplamento

        Ilm = (Ilm-2284)*(-0.01219512);
        Iin = (Iin-2296)*(-0.0027027);
        Iout = (Iout-2284)*(-0.0034722);


        Vout = (Vout-2471)*(-0.32608695652);
        Vdc2 = (Vdc2-2445)*(-0.333333333);
        Vin = (Vin-2488)*(-0.3157894737);
        Vca = (Vca-2202)*(0.46875);              // Placa de cima (monof�sica)


        Vdc1=Vin-Vdc2;

            Eficaz();

            Valfa=(float)(Voltage0[ConversionCount0]);//Tens�o Vout
            Valfa=(Valfa-2510)*(-0.32967032967032967032967032967033);
            Valfa=Valfa*0.0055556;

            Vbeta=(float)(Voltage0[ConversionCount]);
            Vbeta=(Vbeta-2510)*(-0.32967032967032967032967032967033);
            Vbeta=Vbeta*0.0055556;

            FPBVdc();

            //PLLa();
            //Cosseno=Cossenoa;

            //FPBVdc1();
            //FPBVdc2();

            //Iref=0.6*Cossenoa;

            if (ligarede==1)
            {

                GpioDataRegs.GPBSET.bit.GPIO58=1;

            }
            else
            {
                GpioDataRegs.GPBCLEAR.bit.GPIO58=1;

            }


            //PLL();
            if (liga==1)
            {

                //erro=(Iref)-(Iout);





                if(histerese==1)
                {

                }
                else
                {



                    if (malhafechada==1)
                    {

                        if (contamili==60000)
                            {
                                contamili=0;
                                contaseg++;
                            }
                            else
                                contamili++;

                            if (contaseg==40*60)
                            {
                                seg=1;
                                habPosto=1;

                            }

                       //if(desliga==1||Iinef>5||Iinef<-0.5||Vin<-10||Vin>150||Iout>5||Iout<-5||Vpico<170||Vpico>210||Vout<-200||Vout>200)
                       //if(desliga==1||Iinef>1||Iinef<-0.5||Vin<-10||Vin>70||Iout>2||Iout<-2||Ioef>1.5||Vpico<170||Vpico>210||Vout<-60||Vout>60)    // Para retificador
                       if(1==2||desliga==1)
                        {
                            GpioDataRegs.GPBCLEAR.bit.GPIO58=1;

                            EPwm1Regs.CMPA.half.CMPA = Wctrl;
                            EPwm1Regs.CMPB = 0;
                            EPwm2Regs.CMPA.half.CMPA = Wctrl;
                            EPwm2Regs.CMPB = 0;
                            EPwm3Regs.CMPA.half.CMPA = Wctrl;
                            EPwm3Regs.CMPB = 0;

                            desliga=1;
                            while(1);
                        }

                        if(partrampa==1)
                        {
                            if (Irefamp<IrefMax)
                                Irefamp=Irefamp+0.000001;
                            else
                                partrampa=0;

                        }
                        if (rampaneg==1)
                        {
                            if (Irefamp>0.2)
                                Irefamp=Irefamp-0.000001;
                            else
                                rampaneg=0;

                        }


                        if (ilhado==1)
                        {
                        Vref = Vrefamp*Cosseno;



                      if (Cosseno>0)        // C�lculo do erro para o controle PI
                          erroVout2=Vref-Vout;
                      else
                          erroVout2=-Vref+Vout;

                           PI_Vout_Ilhado();



                           erroVout=Vref-Vout;   // C�lculo do erro para o controlador ressonante
                           Vout_ressonante();

                           aciIout = habR*aciIoutR+habPI*aciIoutPI;


                        }
                        else
                            ilhado=0;

                        if(ilhado==0)
                        {

                        //Malha de tens�o
                        //Vref = Vrefamp*Cosseno;
                        /*if (Cosseno>0)
                            {
                             erroVout=Vref-Vout+erroUVcc;

                             }
                        else
                            {
                              erroVout=-Vref+Vout-erroUVcc;
                            }*/
                      //erroVout=Vref-Vout+erroUVcc;



                       //PI_Vout();

                        //Iref=IoutRef;



                    if(ligaMPPT==1)
                      {
                        //PO();
                        //Vpvref = 80;
                        erroVref=Vin-Vpvref;
                        if(FF==1){
                            //PI_FF();
                            Iref=(IoutRef)*Cosseno;
                        }
                            else
                        //PI_Vin();
                        //Iref=(-2*Vin*Iin*0.0055555555555556+IoutRef)*Cosseno;
                        Iref=(IoutRef)*Cosseno;
                       }
                    else{
                        //ligaMPPT=0;
                     Iref=Irefamp*Cosseno;
                    }
                       if (Cosseno>0)           // C�lculo do erro para o controlador PI de corrente
                        {
                            //erroIout=Iref-Iout-UVcc;
                            erroIout=Iref-Iout;
                            //compErro=erroIout/Iref;
                        }
                        else
                        {
                            //erroIout=-Iref+Iout+UVcc;
                            erroIout=-Iref+Iout;
                            //compErro=-erroIout/Iref;
                        }


                        PI_Iout();


                        //erroIout=Iref-Iout;    // Descomentar essa linha para o ressonante e comentar o la�o "if" de cima
                        //P_ressonante();


                        }

                        //aciIout=fabs(IoutRef);

                        if (Cosseno>0)
                        {
                            EPwm1Regs.CMPA.half.CMPA = Wctrl;       // S4
                            EPwm1Regs.CMPB = 0;                     // S3
                            EPwm3Regs.CMPA.half.CMPA = 0;           // S2
                            EPwm3Regs.CMPB = aciIout;               // S1


                        }
                        else
                        {

                            EPwm1Regs.CMPA.half.CMPA = 0;
                            EPwm1Regs.CMPB = aciIout;



                            EPwm3Regs.CMPA.half.CMPA = Wctrl;
                            EPwm3Regs.CMPB = 0;
                        }
                    }

                    else
                    {

                        //if(desliga==1||Iinef>3||Iinef<-0.5||Vin<-10||Vin>200||Iout>5||Iout<-5||Vpico<170||Vpico>210||Vout>230)
                        //if(desliga==1||Iinef>3||Iinef<-0.5||Vin<-10||Vin>200||Iout>8||Iout<-8||Vpico<170||Vpico>210||Vout>230)
                        if(1==2||desliga==1)
                        {
                            //EPwm3Regs.CMPA.half.CMPA = 0;
                            GpioDataRegs.GPBCLEAR.bit.GPIO58=1;

                            EPwm1Regs.CMPA.half.CMPA = Wctrl;
                            EPwm1Regs.CMPB = 0;
                            EPwm2Regs.CMPA.half.CMPA = Wctrl;
                            EPwm2Regs.CMPB = 0;
                            EPwm3Regs.CMPA.half.CMPA = Wctrl;
                            EPwm3Regs.CMPB = 0;

                            desliga=1;
                            while(1);
                        }


                        if (D>0.85)
                            D=0.85;



                       if (Cosseno>0)
                        {
                            EPwm1Regs.CMPA.half.CMPA = Wctrl;       // S4
                            EPwm1Regs.CMPB = 0;                     // S3
                            EPwm3Regs.CMPA.half.CMPA = 0;           // S2
                            EPwm3Regs.CMPB = Cosseno*(D)*Wctrl;     // S1

                        }

                        else
                        {

                            EPwm1Regs.CMPA.half.CMPA = 0;
                            EPwm1Regs.CMPB = -Cosseno*(D)*Wctrl;
                            EPwm3Regs.CMPA.half.CMPA = Wctrl;
                            EPwm3Regs.CMPB = 0;

                        }
                    }
                }
            }

            armazena();
            //SCIA_TX_isr();

            if (habEnvio==1)
            {
                if (SciaRegs.SCICTL2.bit.TXEMPTY==1)
                {
                    SciaRegs.SCIFFTX.bit.TXFIFOXRESET = 1;  // enable TXFIFO
                    SciaRegs.SCIFFTX.bit.TXFFINTCLR = 1 ;  // force TX-ISR
                }
            }


            i=1;
            FlagDeConversao=0;//fim




        GpioDataRegs.GPBCLEAR.bit.GPIO60=1;

        }
    }
} 


interrupt void  adc_isr(void)
{

  // Atribui os dados recebidos para os ADRESULTx
  // Desloca 4 bit aquisi��o analogia em 12 bit 
  // ConversionCount � um contador de convers�o (endere�o do vetor/ponteiro)
  
    Current0 = (AdcRegs.ADCRESULT1 >> 4);  // Ilm
    Current1 = (AdcRegs.ADCRESULT3 >> 4);  // Iin  (Ipv)
    Current2 = (AdcRegs.ADCRESULT5 >> 4);  // Iout

    Voltage0[ConversionCount0]  = (AdcRegs.ADCRESULT4 >> 4);  // Vout
    Voltage1 = (AdcRegs.ADCRESULT2 >> 4);  // Vdc2
    Voltage2 = (AdcRegs.ADCRESULT0 >> 4);  // Vin
    Voltage3 = (AdcRegs.ADCRESULT6 >> 4);  // Vca

  ConversionCount++;
  ConversionCount0++;
  if(ConversionCount == 250){
      ConversionCount = 0;
      ConversionCount0 = 249;
  }
  if(ConversionCount0 == 250){
      ConversionCount0 = 0;
  }



  /*Current0[ConversionCount] = (AdcRegs.ADCRESULT1 >>4);
  Current1[ConversionCount] = (AdcRegs.ADCRESULT2 >>4);
  Voltage1[ConversionCount] = (AdcRegs.ADCRESULT3 >>4);
    */

 // Voltage1[ConversionCount] = converte(AdcRegs.ADCRESULT1 >>4);
 // Voltage2[ConversionCount] = converte(AdcRegs.ADCRESULT2 >>4);
 // Voltage3[ConversionCount] = converte(AdcRegs.ADCRESULT3 >>4);
  //Voltage4[ConversionCount] = converte(AdcRegs.ADCRESULT4 >>4);
  //Voltage5[ConversionCount] = converte(AdcRegs.ADCRESULT5 >>4);
  //Voltage6[ConversionCount] = converte(AdcRegs.ADCRESULT6 >>4);
  //Voltage7[ConversionCount] = converte(AdcRegs.ADCRESULT7 >>4);



 FlagDeConversao=1;
 
  // Reinitialize for next ADC sequence
  AdcRegs.ADCTRL2.bit.RST_SEQ1 = 1;         // Reset SEQ1
  AdcRegs.ADCST.bit.INT_SEQ1_CLR = 1;       // Clear INT SEQ1 bit
  PieCtrlRegs.PIEACK.all = PIEACK_GROUP1;   // Acknowledge interrupt to PIE
}

interrupt void epwm1_isr(void)
{
   // Clear INT flag for this timer
   EPwm1Regs.ETCLR.bit.INT = 1;
   
   // Acknowledge this interrupt to receive more interrupts from group 3
   PieCtrlRegs.PIEACK.all = PIEACK_GROUP3;
}

void ConfigEPwm()
{
   //EPWM - MODULO 1 - CONFIGURACAO
   // Setup TBCLK
   EPwm1Regs.TBPRD = Wctrl;//3000                 // Set timer period 801 TBCLKs = valor maximo da triangular
   EPwm1Regs.TBPHS.half.TBPHS = 0x0000;           // Phase is 0   defasagem = 0
   EPwm1Regs.TBCTR = 0x0000;                      // Clear counter limpa contador
   // Setup counter mode
   EPwm1Regs.TBCTL.bit.SYNCOSEL = 1;
   //EPwm1Regs.TBCTL.bit.CTRMODE = TB_COUNT_UPDOWN; // Count up  PWM Simetrico
   EPwm1Regs.TBCTL.bit.CTRMODE = TB_COUNT_UP; // Count up  PWM Simetrico
   EPwm1Regs.TBCTL.bit.PHSEN = TB_DISABLE;        // Disable phase loading
   EPwm1Regs.TBCTL.bit.HSPCLKDIV = TB_DIV1;       // Clock ratio to SYSCLKOUT
   EPwm1Regs.TBCTL.bit.CLKDIV = TB_DIV1;
   // Setup shadowing
   EPwm1Regs.CMPCTL.bit.SHDWAMODE = CC_SHADOW;
   EPwm1Regs.CMPCTL.bit.SHDWBMODE = CC_SHADOW;
   EPwm1Regs.CMPCTL.bit.LOADAMODE = CC_CTR_ZERO;  // Load on Zero
   EPwm1Regs.CMPCTL.bit.LOADBMODE = CC_CTR_ZERO;   
   // Set actions
   EPwm1Regs.AQCTLA.bit.CAU = AQ_CLEAR;
   EPwm1Regs.AQCTLA.bit.ZRO = AQ_SET;
   EPwm1Regs.AQCTLB.bit.CBU = AQ_SET;
   EPwm1Regs.AQCTLB.bit.ZRO = AQ_CLEAR;           // Set PWM1B on event B, up count

  //EPWM - MODULO 2 - CONFIGURACAO
   // Setup TBCLK
   EPwm2Regs.TBPRD = Wctrl;//3000;                        // Set timer period 801 TBCLKs = valor maximo da triangular
   EPwm2Regs.TBPHS.half.TBPHS = 0;             // Phase is 0   defasagem = 0
   EPwm2Regs.TBCTR = 0x0000;                      // Clear counter limpa contador
   // Setup counter mode
   //EPwm2Regs.TBCTL.bit.SYNCOSEL = 0;
   //EPwm2Regs.TBCTL.bit.CTRMODE = TB_COUNT_UPDOWN; // Count up  PWM Simetrico
   EPwm2Regs.TBCTL.bit.CTRMODE = TB_COUNT_UP; // Count up  PWM Simetrico
   EPwm2Regs.TBCTL.bit.PHSEN = TB_DISABLE;        // Disable phase loading
   EPwm2Regs.TBCTL.bit.HSPCLKDIV = TB_DIV1;       // Clock ratio to SYSCLKOUT
   EPwm2Regs.TBCTL.bit.CLKDIV = TB_DIV1;
   // Setup shadowing
   EPwm2Regs.CMPCTL.bit.SHDWAMODE = CC_SHADOW;
   EPwm2Regs.CMPCTL.bit.SHDWBMODE = CC_SHADOW;
   EPwm2Regs.CMPCTL.bit.LOADAMODE = CC_CTR_ZERO;  // Load on Zero
   EPwm2Regs.CMPCTL.bit.LOADBMODE = CC_CTR_ZERO;   
   // Set actions
   EPwm2Regs.AQCTLA.bit.CAU = AQ_CLEAR;
   EPwm2Regs.AQCTLA.bit.ZRO = AQ_SET;
   EPwm2Regs.AQCTLB.bit.CBU = AQ_SET;
   EPwm2Regs.AQCTLB.bit.ZRO = AQ_CLEAR;           // Set PWM1B on event B, up count


   //EPWM - MODULO 3 - CONFIGURACAO
       // Setup TBCLK
       EPwm3Regs.TBPRD = Wctrl;                        // Set timer period 801 TBCLKs = valor maximo da triangular
       EPwm3Regs.TBPHS.half.TBPHS = 0x0000;           // Phase is 180�   defasagem = 0
       EPwm3Regs.TBCTR = 0x0000;                      // Clear counter limpa contador
       // Setup counter mode
       //EPwm3Regs.TBCTL.bit.CTRMODE = TB_COUNT_UPDOWN;     // Count up  PWM Simetrico
       //EPwm3Regs.TBCTL.bit.PHSEN = TB_ENABLE;            //  enable phase loading
       EPwm3Regs.TBCTL.bit.CTRMODE = TB_COUNT_UP;       // Count up  PWM Simetrico
       EPwm3Regs.TBCTL.bit.PHSEN = TB_DISABLE;         //  disable phase loading
       EPwm3Regs.TBCTL.bit.HSPCLKDIV = TB_DIV1;       // Clock ratio to SYSCLKOUT
       EPwm3Regs.TBCTL.bit.CLKDIV = TB_DIV1;
       EPwm3Regs.TBCTL.bit.SYNCOSEL = 0;
       // Setup shadowing
       EPwm3Regs.CMPCTL.bit.SHDWAMODE = CC_SHADOW;
       EPwm3Regs.CMPCTL.bit.SHDWBMODE = CC_SHADOW;
       EPwm3Regs.CMPCTL.bit.LOADAMODE = CC_CTR_ZERO;  // Load on Zero
       EPwm3Regs.CMPCTL.bit.LOADBMODE = CC_CTR_ZERO;
       // Set actions
       ////(if CMPA>tria - pulso=1)
       EPwm3Regs.AQCTLA.bit.CAU = AQ_CLEAR;             // Set PWM3A on event A, up count (CAU no incremento da triangular) PWM1A pulso alto quando referencia (CMPA) = triangular (AQ_SET)
       EPwm3Regs.AQCTLA.bit.CAD = AQ_SET;           // Clear PWM1A on event A, down count (CAD no decremento da triangular) PWM1A pulsa baixo quando refencia (CMPA) = triangular (AQ_CLEAR)

       EPwm3Regs.AQCTLA.bit.CAU = AQ_CLEAR;
       EPwm3Regs.AQCTLA.bit.ZRO = AQ_SET;
       EPwm3Regs.AQCTLB.bit.CBU = AQ_SET;
       EPwm3Regs.AQCTLB.bit.ZRO = AQ_CLEAR;           // Set PWM3B on event B, up count
}

void Gpio_select(void)
{
    EALLOW;

    /*GpioCtrlRegs.GPAMUX1.all = 0;       // GPIO15 ... GPIO0 = General Puropse I/O
                                       //Histerese usara GPIO_0, GPIO_1 GPIO_2 GPIO_3
    GpioCtrlRegs.GPADIR.all = 0;
    GpioCtrlRegs.GPADIR.bit.GPIO4=1;
    GpioCtrlRegs.GPADIR.bit.GPIO5=1;
    GpioCtrlRegs.GPADIR.bit.GPIO6=1;
    GpioCtrlRegs.GPADIR.bit.GPIO7=1;*/

    //GpioCtrlRegs.GPAMUX1.all = 0;
    GpioCtrlRegs.GPBMUX2.all=0;
    GpioCtrlRegs.GPBDIR.bit.GPIO58=1;


    GpioCtrlRegs.GPBDIR.bit.GPIO60=1;

    GpioCtrlRegs.GPAMUX2.bit.GPIO28 = 1;    // SCIRXDA
    GpioCtrlRegs.GPAMUX2.bit.GPIO29 = 1;    // SCITXDA
    EDIS;
    GpioCtrlRegs.GPBPUD.bit.GPIO60=0;
    GpioCtrlRegs.GPBPUD.bit.GPIO58=0;
    GpioDataRegs.GPBCLEAR.bit.GPIO58 = 1;


    //DELAY_US(3);


    /*GpioCtrlRegs.GPAPUD.bit.GPIO0=4;
    GpioCtrlRegs.GPAPUD.bit.GPIO1=5;
    GpioCtrlRegs.GPAPUD.bit.GPIO2=6;
    GpioCtrlRegs.GPAPUD.bit.GPIO3=7;
    */


}

void SCIA_init()
{
    SciaRegs.SCICCR.all =0x0027;    // 1 stop bit,  No loopback
                                    // ODD parity,8 char bits,
                                    // async mode, idle-line protocol
    SciaRegs.SCICTL1.all =0x0003;   // enable TX, RX, internal SCICLK,
                                    // Disable RX ERR, SLEEP, TXWAKE

    // SYSCLOCKOUT = 150MHz; LSPCLK = 1/4 = 37.5 MHz
    // BRR = (LSPCLK / (9600 x 8)) -1
    // BRR = 487  gives 9605 Baud
    //para 57600  = 80
    //para 115200 =39
    // para 460800 = 9
    //para 17 256000
    //4 = 921600
    //1 para 2 megas

    SciaRegs.SCIHBAUD    = 4 >> 8;     // Highbyte
    SciaRegs.SCILBAUD    = 4 & 0x00FF; // Lowbyte

    SciaRegs.SCICTL2.bit.TXINTENA = 1; // enable SCI-A Tx-ISR
    SciaRegs.SCICTL2.bit.RXBKINTENA = 1;    // enable SCI_A Rx-ISR

    SciaRegs.SCIFFTX.all = 0xC060;  // bit 15 = 1 : relinquish from Reset
                                    // bit 14 = 1 : Enable FIFO
                                    // bit 6 = 1 :  CLR TXFFINT-Flag
                                    // bit 5 = 1 :  enable TX FIFO match
                                    // bit 4-0 :  TX-ISR, if TX FIFO is 0(empty)

    SciaRegs.SCIFFCT.all = 0x0000;  // Set FIFO transfer delay to 0

    SciaRegs.SCIFFTX.bit.TXFIFOXRESET = 1;  // re-enable transmit fifo operation

    SciaRegs.SCIFFRX.all = 0xE06C;  // Rx interrupt level = 12

    SciaRegs.SCICTL1.all = 0x0023;  // Relinquish SCI from Reset


}
void armazena(void)
{

    /* Normaliza��o para a tens�o eficaz (n�o tem sinal)
    * 16 bits ou 2^16=65535
    * normalizando, considerando valor m�ximo de 600V
    * 65535/600 =~ 109
    */

    /* Normaliza��o para a corrente eficaz (n�o tem sinal)
    * 16 bits ou 2^16=65535
    * normalizando, considerando valor m�ximo de 40A
    * 65535/40 =~ 1638
    *
    * Caso fique lento ou ocupe muito espa�o para a transmiss�o, pode ser enviado somente 8bits (256), dado que
    * a corrente ter� amplitude limitada a 40A
    */

    /* Normaliza��o para a Pot�ncia mec�nica (n�o tem sinal)
    * 16 bits ou 2^16=65535
    * normalizando, considerando valor m�ximo de 10000W --> 65535/10000 =~ 7
    */


    /* Normaliza��o para o torque mec�nico (n�o tem sinal)
    * 16 bits ou 2^16=65535
    * normalizando, considerando valor m�ximo de 300 --> 65535/300 =~ 218
    */

    /* Normaliza��o para a Pot�ncia el�trica (n�o tem sinal)
    * 16 bits ou 2^16=65535
    * normalizando, considerando valor m�ximo de 10000W --> 65535/10000 =~ 7
    */

    /* Normaliza��o para o torque el�trico (n�o tem sinal)
    * 16 bits ou 2^16=65535
    * normalizando, considerando valor m�ximo de 300 --> 65535/300 =~ 218
    */

    /* Normaliza��o para a velocidade do GSIP (n�o tem sinal)
    * 16 bits ou 2^16=65535
    * normalizando, considerando valor m�ximo de 100 --> 65535/100 =~ 655
    */

    //tabEnvio[0]=Vabef*109;
    /*tabEnvio[0]=Vabef*109;
    tabEnvio[1]=Vbcef*109;
    tabEnvio[2]=Vcaef*109;
    tabEnvio[3]=Iaef*1638;
    tabEnvio[4]=Ibef*1638;
    tabEnvio[5]=Icef*1638;
    tabEnvio[6]=Pm*7;
    tabEnvio[7]=Tm*218;
    tabEnvio[8]=Pe*7;
    tabEnvio[9]=Te*218;
    tabEnvio[10]=Wm*655;
    tabEnvio[11]=Vcfd;
    tabEnvio[12]=Vcfq;
    tabEnvio[13]=EndSeno;//Teta_e*100;*/


    /*tabEnvio[0]=Vabef;
    tabEnvio[1]=Vbcef;
    tabEnvio[2]=Vcaef;
    tabEnvio[3]=Iaef;
    tabEnvio[4]=Ibef;
    tabEnvio[5]=Icef;
    tabEnvio[6]=Pm;
    tabEnvio[7]=Tm;
    tabEnvio[8]=Pe;
    tabEnvio[9]=Te;
    tabEnvio[10]=Wm;
    tabEnvio[11]=Vcfa;
    tabEnvio[12]=Vcfb;
    tabEnvio[13]=Vcfc;



    tabEnvio[14]=iLa;
    tabEnvio[15]=iLb;
    tabEnvio[16]=iLc;
    tabEnvio[17]=contamili;

    tabEnvio[18]=30000*Cosseno_a;
    */

    //tabEnvio[0]=contamili;
    tabEnvio[0]=Vin;
    tabEnvio[1]=Vout;
    tabEnvio[2]=100*Cosseno;
    tabEnvio[3]=100*Iref;
    tabEnvio[4]=100*Iout;
    /*tabEnvio[2]=Vcfd_filtrado;
   tabEnvio[3]=Vcfq_filtrado;
    tabEnvio[4]=iLd_filtrado;
    tabEnvio[5]=iLq_filtrado;*/



}

interrupt void SCIA_TX_isr(void)
{


    /* Sequ�ncia de envio
     * Vabef
     * Vbcef
     * Vcaef
     * Iaef
     * Ibef
     * Icef
     * Pm
     * Tm
     * Pe
     * Te
     * wn
     *
     *
     */
   // sec=sec+1;




    varS=tabEnvio[0]; //Vout
    SciaRegs.SCITXBUF =(varS>>8)&0xFF;
    SciaRegs.SCITXBUF= varS&0xFF;

    var=tabEnvio[1]; //Cosseno
    SciaRegs.SCITXBUF =(var>>8)&0xFF;
    SciaRegs.SCITXBUF= var&0xFF;

    var=tabEnvio[2]; //Cosseno
    SciaRegs.SCITXBUF =(var>>8)&0xFF;
    SciaRegs.SCITXBUF= var&0xFF;

    var=tabEnvio[3]; //Cosseno
    SciaRegs.SCITXBUF =(var>>8)&0xFF;
    SciaRegs.SCITXBUF= var&0xFF;


    var=tabEnvio[4]; //Cosseno
    SciaRegs.SCITXBUF =(var>>8)&0xFF;
    SciaRegs.SCITXBUF= var&0xFF;


   // varS=tabEnvio[5];
    //SciaRegs.SCITXBUF= varS&0xFF;





    PieCtrlRegs.PIEACK.all = PIEACK_GROUP9;



}



/*void calcEficaz(void)
{
    Iinef_calc += Iin*Iin;
    Ioef_calc += Iout*Iout;

    Vinef_calc += Vin*Vin;
    Voef_calc += Vout*Vout;
    Vdc2ef_calc += Vdc2*Vdc2;
    if (contaEficaz==5000)
        {

            //calculo das correntes eficazes
            Iinef=sqrt(Iinef_calc*0.0002);
            Ioef=sqrt(Ioef_calc*0.0002);

            Vinef=sqrt(Vinef_calc*0.0002);
            Voef=sqrt(Voef_calc*0.0002);
            Vdc2ef=sqrt(Vdc2ef_calc*0.0002);

            Iinef_calc=0;
            Ioef_calc=0;
            Vinef_calc=0;
            Voef_calc=0;
            Vdc2ef_calc=0;

            contaEficaz=1;
        }
        else
            contaEficaz++;
}
*/


