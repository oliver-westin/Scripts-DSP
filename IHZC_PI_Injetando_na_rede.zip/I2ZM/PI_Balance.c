/*
 * PI_Balance.c
 *
 *  Created on: 19 de ago de 2019
 *      Author: leonardo
 */



void PI_UVcc(void)
{
// === Equacao a diferen�a do controlador PI Discretizado atrav�s do M�todo de Tustin ===
// Realimenta��o da sa�da saturada - Leonardo/Bacon
    UVcc = (numzv_U1*erroUVcc) + (numzv_U2*erroUVcc_ant) + UVcc_ant;
    erroUVcc_ant = erroUVcc;  // Salva erro anterior

    if (UVcc>2) UVcc=2;
    if (UVcc<-2) UVcc=-2;

    UVcc_ant = UVcc;        // Salva a��o de controle anterior

}
