void Vout_ressonante(void){
    acdV_h1=((numziV_r1_1*erroVoutR*H1)+(numziV_r1_3*erroVoutR_ant_2*H1)-(denziV_r1_2*acdV_h1_ant)-(denziV_r1_3*acdV_h1_ant_2));//1�Harm�nica
    acdV_h3=((numziV_r3_1*erroVoutR)+(numziV_r3_3*erroVoutR_ant_2)-(denziV_r3_2*acdV_h3_ant)-(denziV_r3_3*acdV_h3_ant_2));//3� Harm�nica
    acdV_h5=((numziV_r5_1*erroVoutR)+(numziV_r5_3*erroVoutR_ant_2)-(denziV_r5_2*acdV_h5_ant)-(denziV_r5_3*acdV_h5_ant_2));//5� Harm�nica
    acdV_h7=((numziV_r7_1*erroVoutR)+(numziV_r7_3*erroVoutR_ant_2)-(denziV_r7_2*acdV_h7_ant)-(denziV_r7_3*acdV_h7_ant_2));//7� Harm�nica
    acdV_h9=((numziV_r9_1*erroVoutR)+(numziV_r9_3*erroVoutR_ant_2)-(denziV_r9_2*acdV_h9_ant)-(denziV_r9_3*acdV_h9_ant_2));//9� Harm�nica
    acdV_h11=((numziV_r11_1*erroVoutR)+(numziV_r11_3*erroVoutR_ant_2)-(denziV_r11_2*acdV_h11_ant)-(denziV_r11_3*acdV_h11_ant_2)); //11� Harm�nica
    acdV_h13=((numziV_r13_1*erroVoutR)+(numziV_r13_3*erroVoutR_ant_2)-(denziV_r13_2*acdV_h13_ant)-(denziV_r13_3*acdV_h13_ant_2)); //13� Harm�nica
    acdV_h15=((numziV_r15_1*erroVoutR)+(numziV_r15_3*erroVoutR_ant_2)-(denziV_r15_2*acdV_h15_ant)-(denziV_r15_3*acdV_h15_ant_2)); //13� Harm�nica


if (acdV_h1>sat_max_vh1) acdV_h1=sat_max_vh1; // Satura��o da 1� Harm�nica
if (acdV_h1<sat_min_vh1) acdV_h1=sat_min_vh1;
if (acdV_h3>sat_max_vh3) acdV_h3=sat_max_vh3; // Satura��o da 3� Harm�nica
if (acdV_h3<sat_min_vh3) acdV_h3=sat_min_vh3;
if (acdV_h5>sat_max_vh5) acdV_h5=sat_max_vh5; // Satura��o da 5� Harm�nica
if (acdV_h5<sat_min_vh5) acdV_h5=sat_min_vh5;
if (acdV_h7>sat_max_vh7) acdV_h7=sat_max_vh7; // Satura��o da 7� Harm�nica
if (acdV_h7<sat_min_vh7) acdV_h7=sat_min_vh7;
if (acdV_h9>sat_max_vh9) acdV_h9=sat_max_vh9; // Satura��o da 9� Harm�nica
if (acdV_h9<sat_min_vh9) acdV_h9=sat_min_vh9;
if (acdV_h11>sat_max_vh11) acdV_h11=sat_max_vh11; // Satura��o da 11� Harm�nica
if (acdV_h11<sat_min_vh11) acdV_h11=sat_min_vh11;
if (acdV_h13>sat_max_vh13) acdV_h13=sat_max_vh13; // Satura��o da 13� Harm�nica
if (acdV_h13<sat_min_vh13) acdV_h13=sat_min_vh13;
if (acdV_h15>sat_max_vh15) acdV_h15=sat_max_vh15; // Satura��o da 15� Harm�nica
if (acdV_h15<sat_min_vh15) acdV_h15=sat_min_vh15;

//acdV_h9=0;acdV_h11=0;
   // aciIout = (acd_h1+acd_h3+acd_h5+acd_h7+acd_h9+acd_h11);
    aciIoutR = acdV_h1+acdV_h3*H3+acdV_h5*H5+acdV_h7*H7+acdV_h9*H9;//+acdV_h11+acdV_h13+acdV_h15;

            if (aciIoutR>0.8*Wctrl) aciIoutR=0.8*Wctrl;
                //if (aciIout<0) aciIout=0;

                if (aciIoutR<-0.8*Wctrl) aciIoutR=-0.8*Wctrl;

    aciIoutR_ant = aciIoutR;        // Salva a��o de controle anterior
    erroVoutR_ant = erroVoutR;
    erroVoutR_ant_2 = erroVoutR_ant;

    acdV_h1_ant_2=acdV_h1_ant;//1� Harmonica
    acdV_h1_ant=acdV_h1;

    acdV_h3_ant_2=acdV_h3_ant; //3� Harmonica
    acdV_h3_ant=acdV_h3;

    acdV_h5_ant_2=acdV_h5_ant; // 5� Harmonica
    acdV_h5_ant=acdV_h5;

    acdV_h7_ant_2=acdV_h7_ant; // 7� Harmonica
    acdV_h7_ant=acdV_h7;

    acdV_h9_ant_2=acdV_h9_ant; // 9� Harmonica
    acdV_h9_ant=acdV_h9;

    acdV_h11_ant_2=acdV_h11_ant; // 11� Harmonica
    acdV_h11_ant=acdV_h11;

    acdV_h13_ant_2=acdV_h13_ant; // 13� Harmonica
    acdV_h13_ant=acdV_h13;

    acdV_h15_ant_2=acdV_h15_ant; // 15� Harmonica
    acdV_h15_ant=acdV_h15;


   if(aciIoutR<0) aciIoutR = -aciIoutR;

}
