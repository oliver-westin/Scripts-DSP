/*
 * PI_Vo_Ilhado.c
 *
 *  Created on: 19 de jan de 2022
 *      Author: Anderson
 */


void PI_Vout_Ilhado(void)
{
// === Equacao a diferen�a do controlador PI Discretizado atrav�s do M�todo de Tustin ===
// Realimenta��o da sa�da saturada para o uso de GVd
    aciVoutPI = (PI_num_Vout1*erroVout) + (PI_num_Vout2*erroVout_ant) + aciVoutPI_ant;



    //aciIout=aciIout+acd_h1_sat;
    if (aciVoutPI>0.8*Wctrl) aciVoutPI=0.8*Wctrl;
    if (aciVoutPI<0) aciVoutPI=0;

    aciVoutPI_ant = aciVoutPI;        // Salva a��o de controle anterior
    erroVoutPI_ant = erroVoutPI;      // Salva erro anterior

    //AcCtrl = aciIoutPI;

}
