void FPBVdc(void)
{
	fpbinVdc[i]=Vdc;
	if (i==1){
		fpboutVdc[i]=(FILTRO_Num0*fpbinVdc[i])+(FILTRO_Num1*fpbinVdc[0])-(FILTRO_Den1*fpboutVdc[0]);
		fpbinVdc[0]=fpbinVdc[i];
		fpboutVdc[0]=fpboutVdc[i];
	}else{
		fpboutVdc[i]=(FILTRO_Num0*fpbinVdc[i]);
	}
	Vdcfil=fpboutVdc[i];
}


void FPBVdc1(void)
{
    fpbinVdc1=Vdc1;
    fpboutVdc1=(FILTRO_Vdc1_Num0*fpbinVdc1)+(FILTRO_Vdc1_Num1*fpbinVdc1_ant)-(FILTRO_Vdc1_Den1*fpboutVdc1_ant);
    fpbinVdc1_ant=fpbinVdc1;
    fpboutVdc1_ant=fpboutVdc1;

    Vdc1fil=fpboutVdc1;
}

void FPBVdc2(void)
{
    fpbinVdc2=Vdc2;
    fpboutVdc2=(FILTRO_Vdc1_Num0*fpbinVdc2)+(FILTRO_Vdc1_Num1*fpbinVdc2_ant)-(FILTRO_Vdc1_Den1*fpboutVdc2_ant);
    fpbinVdc2_ant=fpbinVdc2;
    fpboutVdc2_ant=fpboutVdc2;

    Vdc2fil=fpboutVdc2;
}

void FPBIout(void)
{
    fpbinIout=Iout;
    fpboutIout=(num_FB_Iout_1*fpbinIout)+(num_FB_Iout_1*fpbinIout_ant)-(den_FB_Iout_2*fpboutIout_ant);
    fpbinIout_ant=fpbinIout;
    fpboutIout_ant=fpboutIout;

    Iout_fil = fpboutIout;
}

void FPBIlm(void)
{
    fpbinIlm=Ilm;
    fpboutIlm=(num_FB_Ilm_1*fpbinIlm)+(num_FB_Ilm_1*fpbinIlm_ant)-(den_FB_Ilm_2*fpboutIlm_ant);
    fpbinIlm_ant=fpbinIlm;
    fpboutIlm_ant=fpboutIlm;

    Ilm_fil = fpboutIlm;
}

void FPBVout(void)
{
    fpbinVout=Vout;
    fpboutVout=(num_FB_Vout_1*fpbinVout)+(num_FB_Vout_1*fpbinVout_ant)-(den_FB_Vout_2*fpboutVout_ant);
    fpbinIout_ant=fpbinVout;
    fpboutIout_ant=fpboutVout;

    Vout_fil = fpboutVout;
}
