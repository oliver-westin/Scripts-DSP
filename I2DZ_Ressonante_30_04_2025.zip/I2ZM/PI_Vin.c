/*
 * PI_Vin.c
 *
 *  Created on: 3 de fev de 2022
 *      Author: Anderson Dionizio
 */


void PI_Vin(void)
{
    // Multi- malhas

// === Equacao a diferen�a do controlador PI Discretizado atrav�s do M�todo de Tustin ===

    IoutRef = (PI_numz_Vref1*erroVref) + (PI_numz_Vref2*erroVref_ant) + IoutRef_ant;
    erroVref_ant = erroVref;  // Salva erro anterior

     if (IoutRef>6) IoutRef=6;
    if (IoutRef<0) IoutRef=0;

    IoutRef_ant = IoutRef;        // Salva a��o de controle anterior
}


