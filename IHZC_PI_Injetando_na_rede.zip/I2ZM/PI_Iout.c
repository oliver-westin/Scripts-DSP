/*
 * PI_Iout.c
 *
 *  Created on: 20 de ago de 2019
 *      Author: leonardo
 */


void PI_Iout(void)
{
// === Equacao a diferen�a do controlador PI Discretizado atrav�s do M�todo de Tustin ===
// Realimenta��o da sa�da saturada - Leonardo/Bacon

    aciIout = Ka*((PI_num_Iout1*erroIout) + (PI_num_Iout2*erroIout_ant) + aciIout_ant);


    if (aciIout>0.6*Wctrl) aciIout=0.6*Wctrl;
    if (aciIout<0) aciIout=0;


    aciIout_ant = aciIout;        // Salva a��o de controle anterior
    erroIout_ant = erroIout;


   // AcCtrl = aciIout;

}

/*acd_h1=((numzi_r1_1*erroIout)+(numzi_r1_3*erroIout_ant_2)-(denzi_r1_2*acd_h1_sat_ant)-(denzi_r1_3*acd_h1_sat_ant_2));

    acd_h1_sat = acd_h1;
    if (acd_h1 > Limite_Sat_max_Res){
    acd_h1_sat = Limite_Sat_max_Res;
    }
    if (acd_h1 < Limite_Sat_min_Res){
    acd_h1_sat = Limite_Sat_min_Res;
    }

    acd_h1_sat_ant_2 = acd_h1_sat_ant;  // Salva a��o de controle anterior2 saturada
    acd_h1_sat_ant = acd_h1_sat;        // Salva a��o de controle anterior saturada

    erroIout_ant_2 = erroIout_ant;    // Salva erro anterior2
     // Salva erro anterior
    */

