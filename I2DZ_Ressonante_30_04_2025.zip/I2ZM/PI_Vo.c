/*
 * PI_Vou.c
 *
 *  Created on: 9 de mar de 2020
 *      Author: leonardo
 *      Atualiza��o: Anderson Dionizio
 *      DATA DE ATUALIZA��O: 11/01/2022
 */

/*void PI_Vout(void)
{
    // Multi- malhas

// === Equacao a diferen�a do controlador PI Discretizado atrav�s do M�todo de Tustin ===

    IoutRef = (PI_numz_Vref1*erroVref) + (PI_numz_Vref2*erroVref_ant) + IoutRef_ant;
    erroVref_ant = erroVref;  // Salva erro anterior

    if (IoutRef>3) IoutRef=3;
    if (IoutRef<0) IoutRef=0;

    IoutRef_ant = IoutRef;        // Salva a��o de controle anterior

*/
// === Equacao de diferen�as do controlador PI + Ressonante Discretizado atrav�s do M�todo de Tustin ===


       /* acd_Iout = (numzv_Vo1*erroVout) + (numzv_Vo2*erroVout_ant) + acd_Iout_ant;


        if (IoutRef>1200) IoutRef=1200;
        if (IoutRef<-1200) IoutRef=-1200;

        erroVout_ant = erroVout;  // Salva erro anterior
        acd_Iout_ant = acd_Iout;

        acd_h1=((numzi_r1_1*erroVout)+(numzi_r1_3*erroVout_ant_2)-(denzi_r1_2*acd_h1_sat_ant)-(denzi_r1_3*acd_h1_sat_ant_2));

        acd_h1_sat = acd_h1;
        if (acd_h1 > Limite_Sat_max_Res){
        acd_h1_sat = Limite_Sat_max_Res;
        }
        if (acd_h1 < Limite_Sat_min_Res){
        acd_h1_sat = Limite_Sat_min_Res;
        }

        acd_h1_sat_ant_2 = acd_h1_sat_ant;  // Salva a��o de controle anterior2 saturada
        acd_h1_sat_ant = acd_h1_sat;        // Salva a��o de controle anterior saturada

        erroVout_ant_2 = erroVout_ant;

        IoutRef = acd_Iout+acd_h1_sat;
        */
}





