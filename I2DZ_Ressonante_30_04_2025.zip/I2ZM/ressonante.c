/*
 * ressonante.c
 *
 *  Created on: 13 de jun de 2022
 *      Author: Anderson Dionizio
 */

void P_ressonante(void){
    acd_h1=((numzi_r1_1*erroIout)+(numzi_r1_3*erroIout_ant_2)-(denzi_r1_2*acd_h1_ant)-(denzi_r1_3*acd_h1_ant_2));//1�Harm�nica
    acd_h3=((numzi_r3_1*erroIout)+(numzi_r3_3*erroIout_ant_2)-(denzi_r3_2*acd_h3_ant)-(denzi_r3_3*acd_h3_ant_2));//3� Harm�nica
    acd_h5=((numzi_r5_1*erroIout)+(numzi_r5_3*erroIout_ant_2)-(denzi_r5_2*acd_h5_ant)-(denzi_r5_3*acd_h5_ant_2));//5� Harm�nica
    acd_h7=((numzi_r7_1*erroIout)+(numzi_r7_3*erroIout_ant_2)-(denzi_r7_2*acd_h7_ant)-(denzi_r7_3*acd_h7_ant_2));//7� Harm�nica
    acd_h9=((numzi_r9_1*erroIout)+(numzi_r9_3*erroIout_ant_2)-(denzi_r9_2*acd_h9_ant)-(denzi_r9_3*acd_h9_ant_2));//9� Harm�nica
    acd_h11=((numzi_r11_1*erroIout)+(numzi_r11_3*erroIout_ant_2)-(denzi_r11_2*acd_h11_ant)-(denzi_r11_3*acd_h11_ant_2)); //11 � Harm�nica

    acd_h9 =0;
   // aciIout = (acd_h1+acd_h3+acd_h5+acd_h7+acd_h9+acd_h11);
    aciIout = acd_h1+acd_h3+acd_h5+acd_h7+acd_h9+acd_h11;

            if (aciIout>0.9*Wctrl) aciIout=0.9*Wctrl;
                //if (aciIout<0) aciIout=0;

                if (aciIout<-0.9*Wctrl) aciIout=-0.9*Wctrl;

    aciIout_ant = aciIout;        // Salva a��o de controle anterior
    erroIout_ant = erroIout;
    erroIout_ant_2 = erroIout_ant;

    acd_h1_ant_2=acd_h1_ant;//1� Harmonica
    acd_h1_ant=acd_h1;

    acd_h3_ant_2=acd_h3_ant; //3� Harmonica
    acd_h3_ant=acd_h3;

    acd_h5_ant_2=acd_h5_ant; // 5� Harmonica
    acd_h5_ant=acd_h5;

    acd_h7_ant_2=acd_h7_ant; // 7� Harmonica
    acd_h7_ant=acd_h7;

    acd_h9_ant_2=acd_h9_ant; // 9� Harmonica
    acd_h9_ant=acd_h9;

    acd_h11_ant_2=acd_h11_ant; // 11� Harmonica
   acd_h11_ant=acd_h11;


   if(aciIout<0) aciIout = -aciIout;

}



